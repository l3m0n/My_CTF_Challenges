<?php
//数据库连接信息
$cfg_dbtype = 'mysql';
$cfg_dbhost = 'localhost';
$cfg_dbname = 'dedefun';
$cfg_dbuser = 'dedefun';
$cfg_dbpwd = 'N6e4puVVxFP9Qs7z';
$cfg_dbprefix = 'dede_';
$cfg_db_language = 'utf8';


?>