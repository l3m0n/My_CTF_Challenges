<?php exit('dedecms');?>
a:2:{s:4:"data";a:1:{s:5:"reval";s:2272:"<li><a href='http://ad.dedecms.com' target='_blank' title='DedeCMS广告'>DedeCMS广告</a></li><li><a href='http://service.dedecms.com' target='_blank' title='织梦客户服务中心'>
织梦客户服务中心</a></li><li><a href='http://ask.dedecms.com' target='_blank' title='织梦问答'>
织梦问答</a></li><li><a href='http://www.bufuzao.com' target='_blank' title='不浮躁'>
不浮躁</a></li><li><a href='http://www.d8.cn' target='_blank' title='钓吧'>
钓吧</a></li><li><a href='http://www.shougong.com' target='_blank' title='手工网'>
手工网</a></li><li><a href='http://www.zixue.com' target='_blank' title='自学'>
自学</a></li><li><a href='http://www.163it.com' target='_blank' title='163IT网'>
163IT网</a></li><li><a href='http://www.jielu.com' target='_blank' title='捷路'>
捷路</a></li><li><a href='http://www.q9.cn' target='_blank' title='宠物网'>
宠物网</a></li><li><a href='http://www.bochao.com' target='_blank' title='播潮'>
播潮</a></li><li><a href='http://www.35u.cn' target='_blank' title='35游戏'>
35游戏</a></li><li><a href='http://www.carhome.cn' target='_blank' title='车之家'>
车之家</a></li><li><a href='http://www.x8.cn' target='_blank' title='笑吧'>
笑吧</a></li><li><a href='http://www.chubang.com' target='_blank' title='厨帮'>
厨帮</a></li><li><a href='http://www.xinwen818.com' target='_blank' title='新闻扒一扒'>
新闻扒一扒</a></li><li><a href='http://www.tznj.com' target='_blank' title='投资牛街'>
投资牛街</a></li><li><a href='http://jun.2211.net' target='_blank' title='2211军事'>
2211军事</a></li><li><a href='http://ls.2211.net' target='_blank' title='2211历史'>
2211历史</a></li><li><a href='http://jk.2211.net' target='_blank' title='2211健康'>
2211健康</a></li><li><a href='http://www.hq100.com' target='_blank' title='环球100热点网'>
环球100热点网</a></li><li><a href='http://tools.dedecms.com' target='_blank' title='站长工具'>
站长工具</a></li><li><a href='http://site.desdev.cn' target='_blank' title='DedeCMS建站中心'>
DedeCMS建站中心</a></li><li><a href='http://help.dedecms.com' target='_blank' title='织梦CMS帮助中心'>
织梦CMS帮助中心</a></li><li><a href='http://' target='_blank' title=''></a></li>";}s:7:"timeout";i:1531368512;}