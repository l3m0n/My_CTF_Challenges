<?php
//header('Content-type: text/plain');
include "db.php";

$sql = $_POST['sql'];

// no sleep
if (preg_match("/(sleep|benchmark|count|rpad|concat|<|>)/i", $sql)) {
	die('403: 好好做题,别搞事情.');
}

// deal with for xss
if (preg_match("/(<|>)/i", $sql)) {
	die('403: Waf拦截.');
}

$db = new DB('localhost', 'sandbox', 'QK5VfPFzGeK34Ncp', 'sandbox');

var_dump($db->select($sql));
?>