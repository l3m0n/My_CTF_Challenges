<?php
function random_num($len = 7) {
	$chars = array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9");
	$charsLen = count($chars) - 1;
	shuffle($chars);
	$output = "";
	for ($i = 0; $i < $len; $i++) {
		$output .= $chars[mt_rand(0, $charsLen)];
	}
	return $output;
}

function show_msg_die($msg, $redirect = "") {
	echo "<script>alert(" . $msg . ");";
	if ($redirect) {
		echo "self.location=" . $redirect . ";";
	}
	echo "</script>";
	die($msg);
}

?>