<?php
session_start();
include "function.php";
$_SESSION['code'] = random_num();
$check_code = substr(md5($_SESSION['code']), 0, 6);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Online Mysql Run</title>
    <script type="text/javascript" src="./static/js/jquery.min.js"></script>
</head>
<body>

<h3>Online Mysql Run.</h3>

<textarea id="sqlvalue">
</textarea>
<input type="submit" onclick="execsql();">

<br><br><br>
Output:

<div class="output">
Hello , guy.
</div>

<h3>liuyan</h3>
submit your url.

<form action="./message.php" method="POST">
    content: <input text='text' name="content" value=""></input><br>
    code: <input type='text' name="code" value=""></input> substr(md5(?), 0, 6) = <?=$check_code?><br>
    <input type="submit" name="submit" value="submit">
</form>


</body>
<script type="text/javascript">
function execsql(){
    $.ajax({
    type: "POST",
    url: "./runsql.php",
    data: "sql=" + $("#sqlvalue").val(),
    success: function(data){
        $(".output").html(data);
    },
    error: function(data){
        alert('/error/');
    }
    });
}
</script>
</html>