<?php
session_start();
echo '403: only 127.0.0.1 can find me, so you can get this: http://127.0.0.1/runsql.php';

//echo $_SERVER['REMOTE_ADDR'];
if ($_SERVER['REMOTE_ADDR'] !== '127.0.0.1') {
	die('403: Who are you? only 127.0.0.1 can find me.');
}
// echo $_SERVER['REMOTE_ADDR'];
//
// login check
if (@$_GET['pass'] === 'l3m0nl3m0nl3m0nBot*123') {
	$_SESSION['admin_login'] = 1;
}

if (@$_SESSION['admin_login'] !== 1) {
	die("Who are you?");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Online Mysql Run</title>
</head>
<body>

<h3>Admin Index:</h3>

<img src="./static/img/iamsecret_555.jpg">

I am l3m0n tree.

</body>
</html>