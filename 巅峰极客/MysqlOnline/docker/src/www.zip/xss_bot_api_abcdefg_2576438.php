<?php
include "db.php";
// if ($_SERVER['REMOTE_ADDR'] !== '127.0.0.1') {
// 	die('403: 未授权');
// }

if ($_GET['pass'] !== 'youdontkonw') {
	die('who are you?');
}

$db = new DB('localhost', 'xss_bot', 'bT8gGGe5Fuq5v4rx', 'xss_bot');
$sql = "select id,content from log where status = 0 order by time limit 1";
$result = $db->select($sql);

if (null === @$result[0]) {
	die('Nothing');
}

$content_id = (int) $result[0]['id'];
$sql = "update `xss_bot`.`log` set status = 1 where id = '" . $content_id . "'";
$db->insert($sql);

echo $result[0]['content'];
?>