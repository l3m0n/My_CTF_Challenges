<?php
session_start();
include "function.php";
include "db.php";
if (!isset($_POST['content']) || !isset($_POST['code'])) {
	die('please input content');
}

if (empty($_SESSION['code'])) {
	show_msg_die('empty code', './index.php');
}

if (substr(md5($_POST['code']), 0, 6) !== substr(md5($_SESSION['code']), 0, 6)) {
	show_msg_die('code error', './index.php');
} else {
	$_SESSION['code'] = random_num();
}

// 验证码验证提交频率，禁止提交过快，减轻bot负担

$content = addslashes(@$_POST['content']);

// database - xssbot:
// table - log:
// columns:
// - id
// - content
// - time
// - ip
// - status
$db = new DB('localhost', 'xss_bot', 'bT8gGGe5Fuq5v4rx', 'xss_bot');
$sql = "insert into `log` (`content`,`time`,`ip`,`status`) values ('" . $content . "','" . time() . "','" . $_SERVER['REMOTE_ADDR'] . "','0');";
$db->insert($sql);

echo "ok";
?>
